var class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c =
[
    [ "USA", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c.html#aa02a63f4fd26056135d820f29f33622d", null ],
    [ "CHINA", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c.html#a35311087de1abbd4133f610a02aed69c", null ],
    [ "AUSTRALIA_NEW_ZEALAND", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c.html#a052e3fecd4faf8e15c7c503fb0421a9f", null ],
    [ "BRAZIL", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c.html#a30390f4a7789d4dd4bb0c0781b3012a7", null ],
    [ "ISRAEL", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c.html#a46378a76be60e6037f1c4a2d39c59436", null ],
    [ "JAPAN", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c.html#a8657e83ca3eaa83d306170e1bd5542bd", null ],
    [ "MALAYSIA", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c.html#ad3e4fde17ee1f19545136cd22cfb5e7a", null ],
    [ "KOREA", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c.html#a0ac5ef9cfa77950927ddea7704f96b0d", null ],
    [ "MANUAL", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c.html#a4da3a53f9c5856f3150bd28de9dd1423", null ]
];