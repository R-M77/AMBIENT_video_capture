var class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter =
[
    [ "SetOutputs", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#ae23fb3cbba145280c26e3b9a88695de7", null ],
    [ "GetCounterValues", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#a10319837ce2780cd2b45b02ef8d72e3a", null ],
    [ "SetCounterValues", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#a84b9de838872fe4a8de8346f57fd50d9", null ],
    [ "TYPE_OUTPUT", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#a9f70f1f0e371bd8ddafeb164517d43a5", null ],
    [ "TYPE_LED", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#ab91d932a222863524ca7d7746bfb2c67", null ],
    [ "TYPE_BUZZER", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#a761dd0a4d3c8af4db59273bd8e442436", null ],
    [ "MODE_UNCHANGED", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#ad78139ed7b71181274c021723674ada6", null ],
    [ "MODE_ON", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#acc3a4e78c552190cce52759c55844c11", null ],
    [ "MODE_OFF", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#abf545c95e64138c9dfa195ee30c36632", null ],
    [ "MODE_FLASH", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#a3d5e96d0ddbeb04fc00a0e9ccd642b68", null ],
    [ "FLASH_1HZ", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#ad03f0a77632b616c21f0f415ce2d3ca4", null ],
    [ "FLASH_2HZ", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#a83348a626cf4da10a94d4918a079aaee", null ],
    [ "FLASH_4HZ", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#af81436eda59e24568855babd5f093c81", null ],
    [ "FLASH_8HZ", "class_f_e_d_m_1_1_core_1_1_external_device_1_1_gate_people_counter.html#a5424ad461604b842a70bd7252136b4a0", null ]
];