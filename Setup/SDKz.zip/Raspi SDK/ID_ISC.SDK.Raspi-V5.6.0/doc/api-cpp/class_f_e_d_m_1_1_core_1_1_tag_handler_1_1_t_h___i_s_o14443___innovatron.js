var class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443___innovatron =
[
    [ "GetCardInfo", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443___innovatron.html#a0d7c6286bc9843399403f7946c69f359", null ],
    [ "GetVerlog", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443___innovatron.html#a13f012baca99fa5f1cbd603d26fd7dba", null ],
    [ "GetConfig", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443___innovatron.html#ab053add77e797e66be5612fea6824ad8", null ],
    [ "GetAtr", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443___innovatron.html#a49736cfea5c41f43228687b9145381bf", null ],
    [ "Apdu", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443___innovatron.html#ab510235db36fe15bad983e0a28cdbe87", null ],
    [ "Discard", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443___innovatron.html#aa11b81390f53540edd0749ea7849166c", null ]
];