var class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u =
[
    [ "POINTER_IS_NULL", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#a27e74b40a52632332fe3d10c23280030", null ],
    [ "NO_MEMORY", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#a87610e4275bb6fab3ae3b15b8ead8670", null ],
    [ "UNSUPPORTED_FUNCTION", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#af737059ee2097e5f26b91a802e503441", null ],
    [ "PROTOCOL_LENGTH", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#a1e8feaedce9f558bca9d8cedefbc2f1f", null ],
    [ "CHECKSUM", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#ae47e972c999738f79204533a128b698c", null ],
    [ "TIMEOUT", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#a3ebaa7b18271eb3670f1e93994d726f3", null ],
    [ "UNKNOWN_STATUS", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#ad2caccd4fd976dd6d5af47f3a92ed0f4", null ],
    [ "NO_RECEIVE_DATA", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#a15692e676ee01d357830fdaeb1622f96", null ],
    [ "UNKNOWN_PARAMETER", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#aba201067c44f3a52aaf86b5f1a70e6e3", null ],
    [ "PARAMETER_OUT_OF_RANGE", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#a4161d2b31270fab37b35eaa0c22a1c8b", null ],
    [ "UNKNOWN_ERROR_CODE", "class_f_e_d_m_1_1_core_1_1_error_code_1_1_f_e_f_u.html#a3d34bf7a47d0930ba71749a84bd62d6e", null ]
];