var class_f_e_d_m_1_1_core_1_1_i_brm_table_group_1_1_rssi_item =
[
    [ "m_iAntennaNumber", "class_f_e_d_m_1_1_core_1_1_i_brm_table_group_1_1_rssi_item.html#a79a6f9b895c0b7a1ed218b0717bf7e2c", null ],
    [ "m_iRssi", "class_f_e_d_m_1_1_core_1_1_i_brm_table_group_1_1_rssi_item.html#aaca7251e93818ed7cb7ec16a330b136f", null ],
    [ "m_iPhaseAngle", "class_f_e_d_m_1_1_core_1_1_i_brm_table_group_1_1_rssi_item.html#aa3c912cf850936c319b3701518e950f8", null ]
];