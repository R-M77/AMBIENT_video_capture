var class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___n_x_p___i_c_o_d_e___s_l_i_x2 =
[
    [ "ReadEPC", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___n_x_p___i_c_o_d_e___s_l_i_x2.html#ad5d46e967e93ac930f5f79b9e02f374d", null ],
    [ "GetNxpSystemInformation", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___n_x_p___i_c_o_d_e___s_l_i_x2.html#a7331e01437d203516186b0f8f453d325", null ],
    [ "ProtectPage", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___n_x_p___i_c_o_d_e___s_l_i_x2.html#ab476cd69d242f7fd509173162370b348", null ],
    [ "LockPageProtectionCondition", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___n_x_p___i_c_o_d_e___s_l_i_x2.html#a95ce959ea2b9268efb13a7c9d939b8b0", null ],
    [ "PasswordProtection", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___n_x_p___i_c_o_d_e___s_l_i_x2.html#a6843d82465642cbcf2ef22a7ab57ce4d", null ],
    [ "ReadSignature", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___n_x_p___i_c_o_d_e___s_l_i_x2.html#a006ae3d83edb11d353faa53da040c2a4", null ]
];