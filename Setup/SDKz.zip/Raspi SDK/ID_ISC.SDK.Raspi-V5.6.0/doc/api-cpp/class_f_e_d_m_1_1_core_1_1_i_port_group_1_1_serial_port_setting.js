var class_f_e_d_m_1_1_core_1_1_i_port_group_1_1_serial_port_setting =
[
    [ "SerialPortSetting", "class_f_e_d_m_1_1_core_1_1_i_port_group_1_1_serial_port_setting.html#aa202203e381afb7d7942fdb0091581e5", null ]
];