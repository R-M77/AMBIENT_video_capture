var class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4 =
[
    [ "Init", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#aafe5b2f04a8841430efeac2b3d2e4333", null ],
    [ "SetCID", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#a66228d6ac31b8d643577ddec5210430d", null ],
    [ "EnableCID", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#a36032a1ba5191b95a577e831566cb9f1", null ],
    [ "GetCID", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#ae3baa43d1a1b56ae6303a38033cfcd1b", null ],
    [ "IsCIDEnabled", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#a58566a5b494c18513e0cc7cafb582027", null ],
    [ "SetNAD", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#a7a8794c2322398814863aeac912ff0b6", null ],
    [ "EnableNAD", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#ab69f20b7641516d6407c687e224d15ca", null ],
    [ "GetNAD", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#a26141c3545bd4b16e74ad67d3cdc755b", null ],
    [ "IsNADEnabled", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#a686b3c28b145cf026106f9f16f89463b", null ],
    [ "Apdu", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#afa8dd917b61f735d4d2cfb0a03d2b44d", null ],
    [ "Ping", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#a6701beca92084d92a75dd642aed97d51", null ],
    [ "Deselect", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#ab10a46f0e4c0a6e52546b846dcfb2f43", null ],
    [ "GetTransponderInfo", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#abdcf579837c2cbfbb9c7a665e49c13f1", null ],
    [ "GetLastISOErrorCode", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#aa340122414afdfc1d378a31822b02278", null ],
    [ "GetResponseData", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4.html#a4e52faf63824ea0604bab8ca5b2168ce", null ]
];