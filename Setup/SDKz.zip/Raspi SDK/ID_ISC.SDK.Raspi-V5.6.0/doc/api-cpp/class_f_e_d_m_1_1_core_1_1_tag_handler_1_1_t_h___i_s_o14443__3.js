var class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__3 =
[
    [ "GetProtocolInfo", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__3.html#a349b6d738281cc162727188f3d630ca2", null ],
    [ "GetCardInfo", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__3.html#a3fbdbbd97e0935b9110cc37488c7f081", null ],
    [ "Halt", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__3.html#a3312fc6fd01d1b1db9690012e8be82bf", null ]
];