var class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___infineon =
[
    [ "Read", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___infineon.html#ac1b4b6c6f34d0e2c658d1e2cb9afce26", null ],
    [ "Write", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___infineon.html#a8d98c0daf4c5b5866fd872aeeda0c38c", null ],
    [ "WriteByte", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o15693___infineon.html#a871da4b23675112f3e2b6e361ace8b7f", null ]
];