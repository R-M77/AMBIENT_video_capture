var class_f_e_d_m_1_1_core_1_1_i_notification_listener =
[
    [ "OnNewNotification", "class_f_e_d_m_1_1_core_1_1_i_notification_listener.html#a6b5eb74c5f5796103084dc97efffd052", null ],
    [ "OnNewReaderDiagnostic", "class_f_e_d_m_1_1_core_1_1_i_notification_listener.html#ad56315da7e85dd45a1e652f73834450a", null ],
    [ "OnNewInputEvent", "class_f_e_d_m_1_1_core_1_1_i_notification_listener.html#a2394b13947bcadb5c4273884e308dd82", null ],
    [ "OnNewPeopleCounterEvent", "class_f_e_d_m_1_1_core_1_1_i_notification_listener.html#a5953a55d7c6a84a387737614374a1e06", null ]
];