var class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_e_u =
[
    [ "EUROPE", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_e_u.html#ad29c4256edb430e477e8d15500ce4a71", null ],
    [ "ASIA_OCEANIA", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_e_u.html#a0212b307a404a0d60ad0b5186692efab", null ],
    [ "RUSSIA", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_e_u.html#afc21de31152ea912428460a7a501e5db", null ],
    [ "AFRICA", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_e_u.html#a30669aab5d9407c70f49a73867cffecb", null ],
    [ "INDIA", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_e_u.html#a249854222f773727537a9cafd6cf65da", null ],
    [ "MOROCCO", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_e_u.html#a1fe292f390f701a9eb334f534012a67b", null ],
    [ "MANUAL", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_e_u.html#af80244b2bc0c77f6db556b7b7baeaaea", null ]
];