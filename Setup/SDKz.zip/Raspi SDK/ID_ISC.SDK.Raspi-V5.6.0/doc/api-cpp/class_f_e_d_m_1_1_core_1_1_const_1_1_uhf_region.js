var class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region =
[
    [ "EU", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_e_u.html", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_e_u" ],
    [ "FCC", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c.html", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region_1_1_f_c_c" ],
    [ "GetRegionName", "class_f_e_d_m_1_1_core_1_1_const_1_1_uhf_region.html#a5fb5c7c65590a91241842cccc002e6e8", null ]
];