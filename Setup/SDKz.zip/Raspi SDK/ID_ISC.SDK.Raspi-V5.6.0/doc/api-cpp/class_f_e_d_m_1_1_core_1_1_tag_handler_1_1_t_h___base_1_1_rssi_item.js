var class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___base_1_1_rssi_item =
[
    [ "m_ucAntNo", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___base_1_1_rssi_item.html#a977aec3014e3dc68b4422ab22b08f77c", null ],
    [ "m_ucStatus", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___base_1_1_rssi_item.html#aeca44d1ffbc37fb6d972d3a2224aae8b", null ],
    [ "m_ucRSSI", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___base_1_1_rssi_item.html#af7af96249d1d91992bfc2a097e43dd87", null ],
    [ "m_usPhaseAngle", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___base_1_1_rssi_item.html#ab15b7fa2be482ce48a62f0de8a08b14f", null ]
];