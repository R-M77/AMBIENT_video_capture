var class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4___m_i_f_a_r_e___d_e_s_fire =
[
    [ "Init", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4___m_i_f_a_r_e___d_e_s_fire.html#a96522cf442c6abddec34fa6de7b0e049", null ],
    [ "PLAIN_COMMUNICATION", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4___m_i_f_a_r_e___d_e_s_fire.html#aad99241357b501dce45f4353157e2cac", null ],
    [ "PLAIN_SECURED_BY_MAC", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4___m_i_f_a_r_e___d_e_s_fire.html#a5443aa51a704969eb41f04c99280017b", null ],
    [ "FULLY_ENCIPHERED", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4___m_i_f_a_r_e___d_e_s_fire.html#a0cf44cbd4f1463e6376e74d5e4080d26", null ],
    [ "ISoftCrypto", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4___m_i_f_a_r_e___d_e_s_fire.html#a8a7dd061506b866461ab2aa52c6ca6be", null ],
    [ "IFlexSoftCrypto", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4___m_i_f_a_r_e___d_e_s_fire.html#abad0f8e13fd06092b9fad87f8b2b29fe", null ],
    [ "ISamCrypto", "class_f_e_d_m_1_1_core_1_1_tag_handler_1_1_t_h___i_s_o14443__4___m_i_f_a_r_e___d_e_s_fire.html#acb5b2cd718d2970c6c17211dea0f5aa2", null ]
];